#include "Triangle.h"
#include <cmath>
using namespace std;

double TriangleByVerticle::SideL(double ax, double ay, double bx, double by)
{
	return sqrt(pow(ax - bx, 2) + pow(ay - by, 2));
}

TriangleByVerticle::TriangleByVerticle(double x1, double y1, double x2, double y2, double x3, double y3)
{
	ax = x1;
	bx = x2;
	cx = x3;
	ay = y1;
	by = y2;
	cy = y3;
}

double TriangleByVerticle::GetMedian(int Side)
{
	double AB = SideL(ax, ay, bx, by);
	double BC = SideL(bx, by, cx, cy);
	double AC = SideL(ax, ay, cx, cy);
	switch (Side)
	{
	case 1: return sqrt(2 * pow(BC, 2) + 2 * pow(AC, 2) - pow(AB, 2));
	case 2: return sqrt(2 * pow(AB, 2) + 2 * pow(AC, 2) - pow(BC, 2));
	case 3: return sqrt(2 * pow(AB, 2) + 2 * pow(BC, 2) - pow(AC, 2));
	default:
		return 0;
	}
}

double TriangleByVerticle::GetMidLine(int Side)
{
	double AB = SideL(ax, ay, bx, by);
	double BC = SideL(bx, by, cx, cy);
	double AC = SideL(ax, ay, cx, cy);
	switch (Side)
	{
	case 1: return BC / 2;
	case 2: return AC / 2;
	case 3: return AB / 2;
	default:
		return 0;
	}
}

double TriangleByVerticle::GetInRadius()
{
	double AB = SideL(ax, ay, bx, by);
	double BC = SideL(bx, by, cx, cy);
	double AC = SideL(ax, ay, cx, cy);
	double s = (AB + AC + BC) / 2;
	double area = sqrt(s * (s - AB) * (s - BC) * (s - AC));
	return area / s;
}

double TriangleByVerticle::GetOutRadius()
{
	double AB = SideL(ax, ay, bx, by);
	double BC = SideL(bx, by, cx, cy);
	double AC = SideL(ax, ay, cx, cy);
	double s = (AB + AC + BC) / 2;
	double area = sqrt(s * (s - AB) * (s - BC) * (s - AC));
	return (AB * AC * BC) / (area * 4);
}

TriangleBySide::TriangleBySide(double a, double b, double c)
{
	A = a;
	B = b;
	C = c;
}

double TriangleBySide::GetMedian(int Side)
{
	switch (Side)
	{
	case 1: return sqrt(2 * pow(B, 2) + 2 * pow(C, 2) - pow(A, 2));
	case 2: return sqrt(2 * pow(A, 2) + 2 * pow(C, 2) - pow(B, 2));
	case 3: return sqrt(2 * pow(A, 2) + 2 * pow(B, 2) - pow(C, 2));
	default:
		return 0;
	}
}

double TriangleBySide::GetMidLine(int Side)
{
	switch (Side)
	{
	case 1: return B / 2;
	case 2: return C / 2;
	case 3: return A / 2;
	default:
		return 0;
	}
}

double TriangleBySide::GetInRadius()
{
	double s = (A + B + C) / 2;
	double area = sqrt(s * (s - A) * (s - B) * (s - C));
	return area / s;
}

double TriangleBySide::GetOutRadius()
{
	double s = (A + B + C) / 2;
	double area = sqrt(s * (s - A) * (s - B) * (s - C));
	return (A * B * C) / (area * 4);
}

RightTriangle::RightTriangle(double a, double b) : TriangleBySide(a, b, sqrt(a * a + b * b))
{
}

double RightTriangle::GetInRadius()
{
	return (A + B - C) / 2;
}

double RightTriangle::GetOutRadius()
{
	return C / 2;
}
