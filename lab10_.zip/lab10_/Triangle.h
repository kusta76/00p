#pragma once
class Triangle {
public:
	virtual double GetMedian(int Side) = 0;
	virtual double GetMidLine(int Side) = 0;
	virtual double GetInRadius() = 0;
	virtual double GetOutRadius() = 0;
};

class TriangleByVerticle : public Triangle {
	double ax, ay, bx, by, cx, cy;
	double SideL(double ax, double ay, double bx, double by);
public:
	TriangleByVerticle(double x1, double y1, double x2, double y2, double x3, double y3);
	double GetMedian(int Side) override;
	double GetMidLine(int Side) override;
	double GetInRadius() override;
	double GetOutRadius() override;
};

class TriangleBySide : public Triangle {
protected:
	double A, B, C;
public:
	TriangleBySide(double a, double b, double c);
	double GetMedian(int Side) override;
	double GetMidLine(int Side) override;
	double GetInRadius() override;
	double GetOutRadius() override;
};

class RightTriangle : public TriangleBySide {
public:
	RightTriangle(double a, double b);
	double GetInRadius() override;
	double GetOutRadius() override;
};
